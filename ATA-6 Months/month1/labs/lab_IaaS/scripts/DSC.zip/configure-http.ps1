Configuration WebsiteTest {

    # Import the module that contains the resources we're using.
    Import-DscResource -ModuleName PsDesiredStateConfiguration

    # The Node statement specifies which targets this configuration will be applied to.
    Node 'localhost' {

        # The first resource block ensures that the Web-Server (IIS) feature is enabled.
        WindowsFeature WebServer {
            Ensure = "Present"
            Name =  "Web-Server"
        }

        Script DownloadFiles {

                GetScript = { 
                    return @{ 'Result' = $true }
                }
                SetScript = {
                    $wc = New-Object System.Net.WebClient
		    $url = "https://raw.githubusercontent.com/microsoft/AzureTrailblazerAcademy/master/month1/labs/lab_IaaS/scripts/Atlanta-GA.jpg"
                    $wc.DownloadFile($url, "C:\inetpub\wwwroot\Atlanta-GA.jpg")

                    $url = "https://raw.githubusercontent.com/microsoft/AzureTrailblazerAcademy/master/month1/labs/lab_IaaS/scripts/iisstart.htm"
                    $wc.DownloadFile($url, "C:\inetpub\wwwroot\iisstart.htm")
                }
                TestScript = {
                    $false
                }

           
        }
    }
} 